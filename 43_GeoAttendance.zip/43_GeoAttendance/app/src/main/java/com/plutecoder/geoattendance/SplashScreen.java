package com.plutecoder.geoattendance;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import utils.PreferenceHelper;

public class SplashScreen extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen_layout);

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(3500);
//                  sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {


                    if (!PreferenceHelper.GetIntroShown(SplashScreen.this)) {
                        Intent intent = new Intent(SplashScreen.this, IntroScreenGeo.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    } else {


                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        if (user != null) {
                            // User is signed in.
                            if (PreferenceHelper.getusername(SplashScreen.this).equals("Admin")) {
                                Intent i = new Intent(SplashScreen.this, AdminActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i);
                                SplashScreen.this.finish();
                            } else {
                                Intent i = new Intent(SplashScreen.this, MainActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i);
                                SplashScreen.this.finish();
                            }
                        } else {
                            // No user is signed in.

                            Intent i = new Intent(SplashScreen.this, LoginActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                            SplashScreen.this.finish();
                        }
                    }
                }
            }
        };
        timer.start();

    }

    public void numberseparate(){

        try {
            String str[] = { "3","2","6","5","1","4","8","9"};
            int num1 = 0;
            String num2 = "";
            int n = str.length;
            int arr[] = new int[n];
            int fiveIndex = -1;
            int eightIndex = -1;
            for (int i = 0; i < n; i++) //converting string array into Integer array.
            {
                arr[i] = Integer.parseInt(str[i]);
                if (arr[i] == 5) // finding index of 5 in array
                    fiveIndex = i;
                else if (arr[i] == 8)
                    eightIndex = i; // finding index of 8 in array
            }
            for (int i = fiveIndex; i <= eightIndex; i++) {
                num2 += str[i]; //concatenating all values between 5 and 8 in the array.
                arr[i] = 0; //after concatenation we are assigning zero at that index because
                //we don’t need that value any more.
            }
            for (int num : arr) {
                num1 += num; //here we are adding all values. we have assigned zero in above loop
                //between fiveIndex and eightIndex in the arr.so it will add remaining outer values.
            }
            System.out.println(num1 + (Integer.parseInt(num2))); //print the sum!
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
