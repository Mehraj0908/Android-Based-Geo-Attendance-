package utils;

public class Constant {
    public static String domain="@plutecoder.in";

}
